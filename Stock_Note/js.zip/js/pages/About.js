import React from "react";

function About() {
  return (
    <div>
      <h2>O aplikaci</h2>
      <p>
        Stock Note je jednoduchý investiční zápisník vyvinutý jako projekt v
        Reactu. Umožňuje sledovat nákupy a prodeje akcií a ETF.
      </p>
    </div>
  );
}

export default About;
