import React from "react";

function NotFound() {
  return (
    <div className="text-center">
      <h1>404</h1>
      <p>Stránka nebyla nalezena.</p>
    </div>
  );
}

export default NotFound;
